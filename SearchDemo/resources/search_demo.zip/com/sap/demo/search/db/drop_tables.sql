drop table "SNWD_PD"
drop table "SNWD_TEXTS"
drop procedure findProduct
drop type "PRODUCT_RESULT"